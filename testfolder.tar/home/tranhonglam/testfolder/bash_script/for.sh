
echo "i in {0..10}"
for i in {0..10}
do
echo $i
done

echo "n in {0..20..2}"
for n in {0..20..2}
do
echo $n
done


echo "for (( k=1; k<5; k++))"
for (( k=1; k<5; k++))
do
echo $k
done
