#!/bin/bash
for x in 1 2 3
do
 echo "before $x";
 #continue 2;
 echo "after $x";
done
exit 0
