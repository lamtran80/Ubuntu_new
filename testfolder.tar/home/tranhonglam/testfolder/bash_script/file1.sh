#!/usr/bin/bash

#touch ./a.txt
cat  a.txt < ./textfile.txt 
#exec 11< ./textfile.txt

#cat <&11 

#exec 11<&-
