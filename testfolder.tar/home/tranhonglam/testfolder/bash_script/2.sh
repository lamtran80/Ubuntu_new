#!/usr/bin/bash

echo $exp
