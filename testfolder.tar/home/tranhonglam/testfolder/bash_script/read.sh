
read -p  "Enter your name:" names

echo  " Name:" $names
echo

read -p "Input 2 name:" name name2 
echo "Your enter name are: " $name $name2



