
arr=(    '1' '2' '3' )
echo "${arr[@]}"
for (( i=0 ; i <5 ; i ++ ))
do
echo "Num of array[$i] " ${arr[i]}
done
