#!/usr/bin/bash

foo="This is foo variable"
exp="This is export variable"

export exp

./2.sh


