echo "hello world!"
echo "bash script demmo"
#-- comment  line
echo BASH $BASH
echo Home $HOME
echo "Print working directory $Pwd"

myName='Tran Hong Lam'

echo "My name is " $myName

myVal1=1000


echo "Value " $myVal1

myVal='100 0'

echo "Value after" $myVal

echo "My first echo command"

echo -n "Print text without new line "

#echo -e "\n DHC \t JKJ \c"
